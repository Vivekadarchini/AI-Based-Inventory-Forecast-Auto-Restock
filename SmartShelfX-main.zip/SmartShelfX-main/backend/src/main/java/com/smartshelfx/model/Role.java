package com.smartshelfx.model;

public enum Role {
    ADMIN,
    MANAGER,
    VENDOR
}
